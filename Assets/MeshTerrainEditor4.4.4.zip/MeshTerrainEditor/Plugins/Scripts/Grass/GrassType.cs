﻿namespace MTE
{
    public enum GrassType
    {
        OneQuad,
        ThreeQuad,
        CustomMesh,
    }
}
