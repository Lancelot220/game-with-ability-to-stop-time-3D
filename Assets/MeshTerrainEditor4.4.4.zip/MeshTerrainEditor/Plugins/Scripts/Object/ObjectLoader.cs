using MTE;
using UnityEngine;

/// <summary>
/// This class is only used by MTE editor to keep referenced prefab prototypes.
/// </summary>
public class ObjectLoader : MonoBehaviour
{
    public ObjectDetailList detailList = null;
}
