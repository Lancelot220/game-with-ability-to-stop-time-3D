﻿namespace MTE
{
    public class Detail
    {
        
    }
}