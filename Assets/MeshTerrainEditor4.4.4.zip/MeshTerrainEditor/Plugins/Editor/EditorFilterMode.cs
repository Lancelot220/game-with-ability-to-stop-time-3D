﻿namespace MTE
{
    internal enum EditorFilterMode
    {
        FilteredGameObjects,
        SelectedGameObject
    }
}