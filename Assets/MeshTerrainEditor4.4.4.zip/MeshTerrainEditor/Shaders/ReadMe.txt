Shaders with "Experimental" in its name or path are experimental and not recommended to use in production, because of their bad performance and incomplete tooling.

Delete not-compatible URP shader folders before using MTE.
