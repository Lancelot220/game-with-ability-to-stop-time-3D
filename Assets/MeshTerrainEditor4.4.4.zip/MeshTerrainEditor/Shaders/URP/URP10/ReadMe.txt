Shaders in this folder are generated in following environment:

* Unity 2020.3
* Amplify Shader Editor 1.9.2.2
* URP 10.10.1

Enviroment mismatch might cause shader compile errors. If you got any shader errors, please use lastest compatible ASE(Amplify Shader Editor) to regenerate the shader. Then errors should be resolved.
If you still need help, please contact us. See documentation's Support section for contact methods.

This folder can be deleted if URP version doesn't match or compatible.